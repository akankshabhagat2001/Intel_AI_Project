"""
Migration script to add created_at column to Customer table
"""
import sqlite3
from datetime import datetime

def migrate():
    # Connect to the database
    conn = sqlite3.connect('instance/flavi_dairy_forecasting_ai.sqlite')
    cursor = conn.cursor()
    
    try:
        # Add the created_at column
        cursor.execute('''
            ALTER TABLE customer 
            ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ''')
        
        # Update existing records with a default timestamp
        cursor.execute('''
            UPDATE customer 
            SET created_at = CURRENT_TIMESTAMP 
            WHERE created_at IS NULL
        ''')
        
        conn.commit()
        print("Successfully added created_at column to Customer table")
        
    except Exception as e:
        print(f"Error during migration: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    migrate() 