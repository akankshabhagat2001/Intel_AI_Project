from app import db
from datetime import datetime

class Sales(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sku_id = db.Column(db.String(50), db.ForeignKey('sku.sku_id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    quantity_sold = db.Column(db.Float, nullable=False)
    revenue = db.Column(db.Float, nullable=True)
    region_id = db.Column(db.String(50), nullable=True)
    holiday_flag = db.Column(db.Boolean, default=False)
    festival_flag = db.Column(db.Boolean, default=False)
    promotional_flag = db.Column(db.Boolean, default=False)
    temperature_avg = db.Column(db.Float, nullable=True)
    humidity_avg = db.Column(db.Float, nullable=True)
    competitor_activity_index = db.Column(db.Float, nullable=True)
    fuel_price = db.Column(db.Float, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    user = db.relationship('User', backref='sales')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __init__(self, sku_id, date, quantity_sold, revenue=None, region_id=None, holiday_flag=False, festival_flag=False, promotional_flag=False, temperature_avg=None, humidity_avg=None, competitor_activity_index=None, fuel_price=None, user_id=None):
        self.sku_id = sku_id
        self.date = date
        self.quantity_sold = quantity_sold
        self.revenue = revenue
        self.region_id = region_id
        self.holiday_flag = holiday_flag
        self.festival_flag = festival_flag
        self.promotional_flag = promotional_flag
        self.temperature_avg = temperature_avg
        self.humidity_avg = humidity_avg
        self.competitor_activity_index = competitor_activity_index
        self.fuel_price = fuel_price
        self.user_id = user_id

    def __repr__(self):
        return f'<Sales {self.sku_id} on {self.date}: {self.quantity_sold}>'

    def to_dict(self):
        return {
            'id': self.id,
            'sku_id': self.sku_id,
            'user_id': self.user_id,
            'date': self.date.isoformat(),
            'quantity_sold': self.quantity_sold,
            'revenue': self.revenue,
            'region_id': self.region_id,
            'holiday_flag': self.holiday_flag,
            'festival_flag': self.festival_flag,
            'promotional_flag': self.promotional_flag,
            'temperature_avg': self.temperature_avg,
            'humidity_avg': self.humidity_avg,
            'competitor_activity_index': self.competitor_activity_index,
            'fuel_price': self.fuel_price,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        } 