from app import db
from datetime import datetime

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    sku_id = db.Column(db.String(50), db.ForeignKey('sku.sku_id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, cancelled, completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    customer = db.relationship('Customer', backref='orders')
    sku = db.relationship('SKU', backref='orders')

    def __repr__(self):
        return f'<Order {self.id}: Customer {self.customer_id}, SKU {self.sku_id}, Qty {self.quantity}, Status {self.status}>'

    def to_dict(self):
        return {
            'id': self.id,
            'customer_id': self.customer_id,
            'sku_id': self.sku_id,
            'quantity': self.quantity,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        } 