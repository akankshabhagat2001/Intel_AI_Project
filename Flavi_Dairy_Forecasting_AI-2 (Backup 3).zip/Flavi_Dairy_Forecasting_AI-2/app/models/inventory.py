from app import db
from datetime import datetime

class Inventory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sku_id = db.Column(db.String(50), db.ForeignKey('sku.sku_id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    current_level = db.Column(db.Float, nullable=False)
    production_batch_size = db.Column(db.Float, nullable=False)
    shelf_life_days = db.Column(db.Integer, nullable=False)
    storage_capacity_units = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Inventory {self.sku_id} on {self.date}: {self.current_level}>'

    def to_dict(self):
        return {
            'id': self.id,
            'sku_id': self.sku_id,
            'date': self.date.isoformat(),
            'current_level': self.current_level,
            'production_batch_size': self.production_batch_size,
            'shelf_life_days': self.shelf_life_days,
            'storage_capacity_units': self.storage_capacity_units,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        } 