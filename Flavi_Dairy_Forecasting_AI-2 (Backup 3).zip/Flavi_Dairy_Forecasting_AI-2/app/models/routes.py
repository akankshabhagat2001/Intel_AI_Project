from flask import Blueprint, jsonify, request
from app import db
from app.models.sales import Sales
import pandas as pd
from datetime import datetime

from flask import current_app as app

@app.route("/predict/<sku_id>")
def predict(sku_id):
    sales_data = Sales.query.filter_by(sku_id=sku_id).all()
    if not sales_data:
        return jsonify({"error": "No sales data found"}), 404

    df = pd.DataFrame([{"date": s.date, "quantity_sold": s.quantity_sold} for s in sales_data])

    return df.tail(30).to_json(orient="records")
