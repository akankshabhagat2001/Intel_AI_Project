from app import db
from datetime import datetime

class SKU(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sku_id = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    packaging_type = db.Column(db.String(50), nullable=False)
    unit_of_measure = db.Column(db.String(20), nullable=False)
    processing_time_hours = db.Column(db.Float, nullable=False)
    packaging_time_hours = db.Column(db.Float, nullable=False)
    storage_requirement_cubic_meters = db.Column(db.Float, nullable=False)
    min_threshold = db.Column(db.Float, default=0)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    sales = db.relationship('Sales', backref='sku', lazy='dynamic')
    inventory = db.relationship('Inventory', backref='sku', lazy='dynamic')

    def __init__(self, sku_id, name, category, packaging_type, unit_of_measure, processing_time_hours, packaging_time_hours, storage_requirement_cubic_meters, min_threshold=0, description=None):
        self.sku_id = sku_id
        self.name = name
        self.category = category
        self.packaging_type = packaging_type
        self.unit_of_measure = unit_of_measure
        self.processing_time_hours = processing_time_hours
        self.packaging_time_hours = packaging_time_hours
        self.storage_requirement_cubic_meters = storage_requirement_cubic_meters
        self.min_threshold = min_threshold
        if description:
            self.description = description

    def __repr__(self):
        return f'<SKU {self.sku_id}: {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'sku_id': self.sku_id,
            'name': self.name,
            'category': self.category,
            'packaging_type': self.packaging_type,
            'unit_of_measure': self.unit_of_measure,
            'processing_time_hours': self.processing_time_hours,
            'packaging_time_hours': self.packaging_time_hours,
            'storage_requirement_cubic_meters': self.storage_requirement_cubic_meters,
            'min_threshold': self.min_threshold,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        } 