// ===== FLACI DAIRY SOLUTIONS - MAIN JAVASCRIPT FILE =====

// Global variables
let currentTheme = localStorage.getItem('theme') || 'light';
let animationsEnabled = true;
let notifications = [];
let searchTimeout;

// ===== UTILITY FUNCTIONS =====

/**
 * Debounce function to limit how often a function can be called
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} Debounced function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle function to limit function execution frequency
 * @param {Function} func - Function to throttle
 * @param {number} limit - Time limit in milliseconds
 * @returns {Function} Throttled function
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    }
}

/**
 * Check if element is in viewport
 * @param {HTMLElement} element - Element to check
 * @returns {boolean} True if element is in viewport
 */
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

// ===== ANIMATION FUNCTIONS =====

/**
 * Initialize animations for dashboard elements
 */
function initializeAnimations() {
    if (!animationsEnabled) return;

    // Add staggered animation to cards
    const cards = document.querySelectorAll('.animate-fade-in');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
    });

    // Add slide animations for different sections
    const slideElements = document.querySelectorAll('.animate-slide-left, .animate-slide-right');
    slideElements.forEach((element, index) => {
        element.style.animationDelay = `${index * 0.15}s`;
    });

    // Add pulse animation to important elements
    const pulseElements = document.querySelectorAll('.animate-pulse');
    pulseElements.forEach(element => {
        element.style.animationDelay = '0.5s';
    });
}

/**
 * Add scroll-triggered animations
 */
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements that should animate on scroll
    const scrollElements = document.querySelectorAll('.stats-card, .metric-card, .table-custom');
    scrollElements.forEach(element => {
        observer.observe(element);
    });
}

// ===== INTERACTIVE ELEMENTS =====

/**
 * Initialize hover effects for metric cards
 */
function initializeMetricCardHovers() {
    const metricCards = document.querySelectorAll('.metric-card');
    metricCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            if (animationsEnabled) {
                this.style.transform = 'translateY(-5px) scale(1.02)';
            }
        });

        card.addEventListener('mouseleave', function() {
            if (animationsEnabled) {
                this.style.transform = 'translateY(0) scale(1)';
            }
        });
    });
}

/**
 * Initialize table row hover effects
 */
function initializeTableHovers() {
    const tableRows = document.querySelectorAll('.table-custom tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            if (animationsEnabled) {
                this.style.transform = 'scale(1.01)';
            }
        });

        row.addEventListener('mouseleave', function() {
            if (animationsEnabled) {
                this.style.transform = 'scale(1)';
            }
        });
    });
}

/**
 * Initialize navigation hover effects
 */
function initializeNavigationHovers() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('mouseenter', function() {
            if (animationsEnabled) {
                this.style.transform = 'translateY(-2px)';
            }
        });

        link.addEventListener('mouseleave', function() {
            if (animationsEnabled) {
                this.style.transform = 'translateY(0)';
            }
        });
    });
}

// ===== CHART FUNCTIONS =====

/**
 * Initialize charts if Chart.js is available
 */
function initializeCharts() {
    if (typeof Chart === 'undefined') return;

    // Sales Chart
    const salesChartCanvas = document.getElementById('sales-chart');
    if (salesChartCanvas) {
        const salesCtx = salesChartCanvas.getContext('2d');
        new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Sales',
                    data: [12, 19, 3, 5, 2, 3],
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });
    }

    // Inventory Chart
    const inventoryChartCanvas = document.getElementById('inventory-chart');
    if (inventoryChartCanvas) {
        const inventoryCtx = inventoryChartCanvas.getContext('2d');
        new Chart(inventoryCtx, {
            type: 'doughnut',
            data: {
                labels: ['Milk', 'Cheese', 'Yogurt', 'Butter'],
                datasets: [{
                    data: [300, 150, 100, 80],
                    backgroundColor: [
                        '#667eea',
                        '#f093fb',
                        '#4facfe',
                        '#fa709a'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });
    }
}

// ===== FORM HANDLING =====

/**
 * Initialize form enhancements
 */
function initializeForms() {
    // Add floating labels effect
    const formInputs = document.querySelectorAll('.form-control, .form-select');
    formInputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('focused');
        });

        input.addEventListener('blur', function() {
            if (!this.value) {
                this.parentElement.classList.remove('focused');
            }
        });
    });

    // Add form validation feedback
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            if (!isValid) {
                e.preventDefault();
                showNotification('Please fill in all required fields', 'error');
            }
        });
    });
}

// ===== NOTIFICATION SYSTEM =====

/**
 * Show notification message
 * @param {string} message - Message to display
 * @param {string} type - Type of notification (success, error, warning, info)
 * @param {number} duration - Duration in milliseconds
 */
function showNotification(message, type = 'info', duration = 5000) {
    const container = document.querySelector('.notification-container');
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;

    notification.innerHTML = `
        <div class="notification-title">${getNotificationTitle(type)}</div>
        <div class="notification-message">${message}</div>
        <button class="notification-close" onclick="closeNotification(this)">
            <i class="fas fa-times"></i>
        </button>
    `;

    container.appendChild(notification);

    // Animate in
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);

    // Auto remove after duration
    if (duration > 0) {
        setTimeout(() => {
            closeNotification(notification.querySelector('.notification-close'));
        }, duration);
    }

    // Add to notifications array
    notifications.push(notification);

    // Limit notifications
    if (notifications.length > 5) {
        const oldNotification = notifications.shift();
        if (oldNotification && oldNotification.parentNode) {
            oldNotification.parentNode.removeChild(oldNotification);
        }
    }
}

/**
 * Get icon for notification type
 * @param {string} type - Notification type
 * @returns {string} Icon class name
 */
function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

function getNotificationTitle(type) {
    const titles = {
        'success': 'Success',
        'warning': 'Warning',
        'error': 'Error',
        'info': 'Information'
    };
    return titles[type] || 'Notification';
}

function closeNotification(button) {
    const notification = button.closest('.notification');
    if (notification) {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
            // Remove from array
            const index = notifications.indexOf(notification);
            if (index > -1) {
                notifications.splice(index, 1);
            }
        }, 300);
    }
}

// ===== THEME MANAGEMENT =====

/**
 * Toggle between light and dark themes
 */
function toggleTheme() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    applyTheme(currentTheme);
    localStorage.setItem('theme', currentTheme);

    // Update toggle icon
    const icon = document.querySelector('.theme-toggle i');
    if (icon) {
        icon.className = currentTheme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
    }

    // Show notification
    showNotification('Theme changed to ' + currentTheme + ' mode', 'info');
}

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
}

/**
 * Initialize theme from localStorage
 */
function initializeTheme() {
    // Apply saved theme
    applyTheme(currentTheme);

    // Create theme toggle button if it doesn't exist
    if (!document.querySelector('.theme-toggle')) {
        createThemeToggle();
    }

    // Add theme toggle event listener
    const themeToggle = document.querySelector('.theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
}

function createThemeToggle() {
    const toggle = document.createElement('div');
    toggle.className = 'theme-toggle';
    toggle.innerHTML = '<i class="fas fa-moon"></i>';
    toggle.title = 'Toggle Dark/Light Mode';
    document.body.appendChild(toggle);
}

// ===== RESPONSIVE HANDLING =====

/**
 * Handle responsive behavior
 */
function handleResponsive() {
    const handleResize = debounce(() => {
        const isMobile = window.innerWidth <= 768;

        // Adjust animations for mobile
        if (isMobile) {
            animationsEnabled = false;
        } else {
            animationsEnabled = true;
        }

        // Update layout classes
        document.body.classList.toggle('mobile-view', isMobile);
    }, 250);

    window.addEventListener('resize', handleResize);
    handleResize(); // Initial call
}

// ===== ACCESSIBILITY =====

/**
 * Initialize accessibility features
 */
function initializeAccessibility() {
    // Add keyboard navigation for cards
    const interactiveCards = document.querySelectorAll('.metric-card, .stats-card');
    interactiveCards.forEach(card => {
        card.setAttribute('tabindex', '0');
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.click();
            }
        });
    });

    // Add skip to content link
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.textContent = 'Skip to main content';
    skipLink.className = 'skip-link';
    skipLink.style.cssText = `
        position: absolute;
        top: -40px;
        left: 6px;
        background: #000;
        color: white;
        padding: 8px;
        text-decoration: none;
        z-index: 10000;
    `;
    document.body.insertBefore(skipLink, document.body.firstChild);

    // Add keyboard navigation
    addKeyboardNavigation();

    // Add ARIA labels
    addAriaLabels();

    // Add focus management
    addFocusManagement();
}

function addKeyboardNavigation() {
    document.addEventListener('keydown', function(event) {
        // Ctrl/Cmd + K for search
        if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
            event.preventDefault();
            const searchInput = document.querySelector('.search-input');
            if (searchInput) {
                searchInput.focus();
            }
        }

        // Ctrl/Cmd + T for theme toggle
        if ((event.ctrlKey || event.metaKey) && event.key === 't') {
            event.preventDefault();
            toggleTheme();
        }
    });
}

function addAriaLabels() {
    // Add ARIA labels to interactive elements
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        if (!button.getAttribute('aria-label')) {
            const text = button.textContent.trim();
            button.setAttribute('aria-label', text);
        }
    });

    // Add ARIA labels to icons
    const icons = document.querySelectorAll('.fas, .far, .fab');
    icons.forEach(icon => {
        const parent = icon.parentElement;
        if (parent && !parent.getAttribute('aria-label')) {
            const text = parent.textContent.trim();
            if (text) {
                parent.setAttribute('aria-label', text);
            }
        }
    });
}

function addFocusManagement() {
    // Add focus indicators
    const focusableElements = document.querySelectorAll('button, input, select, textarea, a, [tabindex]');
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '2px solid var(--primary-color)';
            this.style.outlineOffset = '2px';
        });

        element.addEventListener('blur', function() {
            this.style.outline = '';
            this.style.outlineOffset = '';
        });
    });
}

// ===== SEARCH FUNCTIONALITY =====
function initializeSearch() {
    const searchInputs = document.querySelectorAll('.search-input');
    searchInputs.forEach(input => {
        input.addEventListener('input', handleSearch);
        input.addEventListener('keydown', handleSearchKeydown);
    });
}

function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    const searchableElements = document.querySelectorAll('[data-searchable]');

    // Clear previous timeout
    clearTimeout(searchTimeout);

    // Debounce search
    searchTimeout = setTimeout(() => {
        searchableElements.forEach(element => {
            const text = element.textContent.toLowerCase();
            const shouldShow = text.includes(searchTerm);
            element.style.display = shouldShow ? '' : 'none';

            // Add highlight effect
            if (searchTerm && shouldShow) {
                highlightText(element, searchTerm);
            } else {
                removeHighlight(element);
            }
        });

        // Show results count
        const visibleElements = Array.from(searchableElements).filter(el => el.style.display !== 'none');
        showSearchResults(visibleElements.length, searchableElements.length);
    }, 300);
}

function handleSearchKeydown(event) {
    if (event.key === 'Escape') {
        event.target.value = '';
        handleSearch(event);
        event.target.blur();
    }
}

function highlightText(element, searchTerm) {
    const text = element.textContent;
    const regex = new RegExp(`(${searchTerm})`, 'gi');
    element.innerHTML = text.replace(regex, '<mark>$1</mark>');
}

function removeHighlight(element) {
    const marks = element.querySelectorAll('mark');
    marks.forEach(mark => {
        mark.outerHTML = mark.textContent;
    });
}

function showSearchResults(visible, total) {
    // Remove existing results display
    const existing = document.querySelector('.search-results');
    if (existing) {
        existing.remove();
    }

    if (visible < total) {
        const results = document.createElement('div');
        results.className = 'search-results alert alert-info';
        results.innerHTML = `<i class="fas fa-search me-2"></i>Showing ${visible} of ${total} results`;

        const searchContainer = document.querySelector('.search-container');
        if (searchContainer) {
            searchContainer.appendChild(results);
        }
    }
}

// ===== REAL-TIME UPDATES =====
function initializeRealTimeUpdates() {
    // Simulate real-time data updates
    setInterval(updateMetrics, 30000); // Update every 30 seconds

    // Add live indicators
    addLiveIndicators();
}

function updateMetrics() {
    const metricValues = document.querySelectorAll('.metric-value');
    metricValues.forEach(metric => {
        const currentValue = parseInt(metric.textContent.replace(/[^\d]/g, ''));
        const newValue = currentValue + Math.floor(Math.random() * 10) - 5;

        // Animate the change
        animateValueChange(metric, currentValue, newValue);
    });

    // Show notification
    showNotification('Dashboard metrics updated', 'info', 2000);
}

function animateValueChange(element, oldValue, newValue) {
    const duration = 1000;
    const start = performance.now();

    function update(currentTime) {
        const elapsed = currentTime - start;
        const progress = Math.min(elapsed / duration, 1);

        const current = Math.floor(oldValue + (newValue - oldValue) * progress);
        element.textContent = element.textContent.replace(/\d+/, current);

        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }

    requestAnimationFrame(update);
}

function addLiveIndicators() {
    const liveElements = document.querySelectorAll('.metric-card, .stats-card');
    liveElements.forEach(element => {
        const indicator = document.createElement('div');
        indicator.className = 'live-indicator';
        indicator.innerHTML = '<i class="fas fa-circle"></i>';
        indicator.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            color: #28a745;
            font-size: 0.8rem;
            animation: pulse 2s infinite;
        `;
        element.style.position = 'relative';
        element.appendChild(indicator);
    });
}

window.showSpinner = function() {
    var spinner = document.getElementById('global-spinner');
    if (spinner) spinner.style.display = 'flex';
};
window.hideSpinner = function() {
    var spinner = document.getElementById('global-spinner');
    if (spinner) spinner.style.display = 'none';
};

window.FlaciApp = {
    showNotification,
    toggleTheme,
    initializeCharts,
    debounce,
    throttle
};

// Render forecast charts for each SKU
function renderForecastCharts(skus) {
    skus.forEach(function(sku_id) {
        fetch(`/api/forecast/${sku_id}`)
            .then(response => response.json())
            .then(data => {
                const ctx = document.getElementById(`forecast-chart-${sku_id}`).getContext('2d');
                const labels = data.data.map(d => d.date);
                const forecast = data.data.map(d => d.forecast);
                const lower = data.data.map(d => d.lower);
                const upper = data.data.map(d => d.upper);
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [
                            {
                                label: 'Forecast',
                                data: forecast,
                                borderColor: '#007bff',
                                backgroundColor: 'rgba(0,123,255,0.1)',
                                fill: true
                            },
                            {
                                label: 'Lower Bound',
                                data: lower,
                                borderColor: '#6c757d',
                                borderDash: [5,5],
                                fill: false
                            },
                            {
                                label: 'Upper Bound',
                                data: upper,
                                borderColor: '#6c757d',
                                borderDash: [5,5],
                                fill: false
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: { display: true },
                            title: { display: false }
                        },
                        scales: {
                            x: { display: true, title: { display: true, text: 'Date' } },
                            y: { display: true, title: { display: true, text: 'Units' } }
                        }
                    }
                });
                // Alerts
                const alertsDiv = document.getElementById(`forecast-alerts-${sku_id}`);
                if (data.alerts && data.alerts.length > 0) {
                    alertsDiv.innerHTML = data.alerts.map(a => `<div><i class='fas fa-exclamation-triangle'></i> ${a}</div>`).join('');
                }
                // Recommendation
                const recDiv = document.getElementById(`forecast-recommendation-${sku_id}`);
                if (data.recommendation) {
                    recDiv.innerHTML = `<i class='fas fa-lightbulb'></i> ${data.recommendation}`;
                }
            });
    });
}

// ===== SALES TREND CHART FOR SALES PAGE =====
document.addEventListener('DOMContentLoaded', function() {
    const skuSelect = document.getElementById('sku-select');
    const salesChartCanvas = document.getElementById('sales-chart');
    let salesChartInstance = null;

    // Populate SKU dropdown
    if (skuSelect) {
        fetch('/api/skus')
            .then(response => response.json())
            .then(skus => {
                skus.forEach(sku => {
                    const option = document.createElement('option');
                    option.value = sku.sku_id;
                    option.textContent = sku.name;
                    skuSelect.appendChild(option);
                });
            });
    }

    // Handle SKU selection and date filter
    if (skuSelect && salesChartCanvas) {
        function fetchAndRenderSales() {
            const skuId = skuSelect.value;
            const totalSalesValue = document.getElementById('total-sales-value');
            const startDate = document.getElementById('sales-start-date').value;
            const endDate = document.getElementById('sales-end-date').value;
            if (!skuId) {
                if (salesChartInstance) {
                    salesChartInstance.destroy();
                    salesChartInstance = null;
                }
                if (totalSalesValue) totalSalesValue.textContent = '-';
                return;
            }
            let url = `/api/sales/${skuId}`;
            const params = [];
            if (startDate) params.push(`start_date=${startDate}`);
            if (endDate) params.push(`end_date=${endDate}`);
            if (params.length > 0) url += '?' + params.join('&');
            fetch(url)
                .then(response => response.json())
                .then(sales => {
                    // Aggregate sales by date
                    const salesByDate = {};
                    let totalSales = 0;
                    sales.forEach(sale => {
                        const date = sale.date;
                        if (!salesByDate[date]) salesByDate[date] = 0;
                        salesByDate[date] += sale.quantity_sold;
                        totalSales += sale.quantity_sold;
                    });
                    const labels = Object.keys(salesByDate);
                    const data = Object.values(salesByDate);
                    // Update total sales card
                    if (totalSalesValue) totalSalesValue.textContent = totalSales;
                    // Update chart
                    if (salesChartInstance) salesChartInstance.destroy();
                    salesChartInstance = new Chart(salesChartCanvas.getContext('2d'), {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Sales',
                                data: data,
                                borderColor: '#667eea',
                                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                                tension: 0.4,
                                fill: true
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: { position: 'top' },
                                title: { display: false }
                            },
                            scales: {
                                x: { display: true, title: { display: true, text: 'Date' } },
                                y: { display: true, title: { display: true, text: 'Units Sold' } }
                            }
                        }
                    });
                });
        }
        skuSelect.addEventListener('change', fetchAndRenderSales);
        const salesDateFilter = document.getElementById('sales-date-filter');
        if (salesDateFilter) {
            salesDateFilter.addEventListener('submit', function(e) {
                e.preventDefault();
                fetchAndRenderSales();
            });
        }
    }
});