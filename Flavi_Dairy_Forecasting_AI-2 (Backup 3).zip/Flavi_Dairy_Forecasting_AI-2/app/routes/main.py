from flask import Blueprint, render_template, jsonify, request, session, redirect, url_for, flash, Response
from app.models.sku import SKU
from app.models.sales import Sales
from app.models.inventory import Inventory
from app import db
from datetime import datetime, timedelta
import numpy as np
from app.models.user import User
from werkzeug.security import generate_password_hash
from functools import wraps
import random
from app.forecasting.prophet_model import forecast_sales
import pandas as pd
import io
import csv
from flask_login import login_required, login_user, logout_user, current_user
import re
import uuid
from flask_mail import Message
from app import mail
import hashlib
from app.models.customer import Customer
from sqlalchemy import func
from collections import Counter
from app.models.order import Order

bp = Blueprint('main', __name__)

@bp.route('/')
def index():
    return render_template('index.html', user=current_user if current_user.is_authenticated else None)

@bp.route('/dashboard')
@login_required
def dashboard():
    # If logged in as customer
    customer_id = session.get('customer_id')
    if customer_id:
        customer = Customer.query.get(customer_id)
        skus = SKU.query.all()
        return render_template('dashboard.html', user=customer, sales=[], latest_pending_orders=[], utilization_data=[], skus=skus)
    # If logged in as admin
    user_id = session.get('user_id')
    user = User.query.get(user_id) if user_id else (current_user if hasattr(current_user, 'is_admin') else None)
    if user and hasattr(user, 'is_admin') and user.is_admin():
        orders = Order.query.filter_by(status='pending').order_by(Order.created_at.desc()).limit(10).all()
        latest_pending_orders = []
        for order in orders:
            customer = Customer.query.get(order.customer_id)
            sku = SKU.query.filter_by(sku_id=order.sku_id).first()
            latest_pending_orders.append({
                'id': order.id,
                'customer': customer.username if customer else order.customer_id,
                'sku': sku.name if sku else order.sku_id,
                'quantity': order.quantity,
                'date': order.created_at.strftime('%Y-%m-%d %H:%M'),
            })
        # Utilization data
        utilization_data = []
        skus = SKU.query.all()
        for sku in skus:
            latest_inventory = Inventory.query.filter_by(sku_id=sku.sku_id).order_by(Inventory.date.desc()).first()  # type: ignore
            if latest_inventory:
                processing_util = min(1.0, sku.processing_time_hours / 24.0) * 100 if sku.processing_time_hours else 0
                packaging_util = min(1.0, sku.packaging_time_hours / 24.0) * 100 if sku.packaging_time_hours else 0
                storage_util = min(1.0, latest_inventory.current_level / latest_inventory.storage_capacity_units) * 100 if latest_inventory.storage_capacity_units else 0
            else:
                processing_util = packaging_util = storage_util = 0
            utilization_data.append({
                'sku_id': sku.sku_id,
                'name': sku.name,
                'processing_utilization': round(processing_util, 2),
                'packaging_utilization': round(packaging_util, 2),
                'storage_utilization': round(storage_util, 2)
            })
        sales = Sales.query.all()
        total_sales = sum(sale.revenue or 0 for sale in sales)
        total_orders = Order.query.count()
        total_customers = Customer.query.count()
        total_skus = SKU.query.count()
        low_stock_skus = 0
        for sku in skus:
            latest_inventory = Inventory.query.filter_by(sku_id=sku.sku_id).order_by(Inventory.date.desc()).first()  # type: ignore
            if latest_inventory and latest_inventory.current_level <= sku.min_threshold:
                low_stock_skus += 1
        pending_orders_count = Order.query.filter_by(status='pending').count()  # type: ignore
        completed_orders_count = Order.query.filter_by(status='completed').count()  # type: ignore
        return render_template(
            'dashboard.html',
            user=user,
            sales=sales,
            latest_pending_orders=latest_pending_orders,
            utilization_data=utilization_data,
            skus=skus,
            total_sales=total_sales,
            total_orders=total_orders,
            total_customers=total_customers,
            total_skus=total_skus,
            low_stock_skus=low_stock_skus,
            pending_orders_count=pending_orders_count,
            completed_orders_count=completed_orders_count
        )
    skus = SKU.query.all()
    sales = Sales.query.filter_by(user_id=user.id).all() if user is not None else []
    return render_template('dashboard.html', user=user, sales=sales, latest_pending_orders=[], utilization_data=[], skus=skus)

@bp.route('/sales')
@login_required
def sales_page():
    return render_template('sales.html')

@bp.route('/inventory')
@login_required
def inventory_page():
    # Fetch all inventory records, join with SKU
    inventory_records = Inventory.query.order_by(Inventory.date.desc()).all()
    inventory_data = []
    for inv in inventory_records:
        sku = SKU.query.filter_by(sku_id=inv.sku_id).first()
        min_threshold = sku.min_threshold if sku and sku.min_threshold is not None else 0
        inventory_data.append({
            'id': inv.id,
            'sku_id': inv.sku_id,
            'name': sku.name if sku else inv.sku_id,
            'date': inv.date.strftime('%Y-%m-%d'),
            'current_level': inv.current_level,
            'production_batch_size': inv.production_batch_size,
            'shelf_life_days': inv.shelf_life_days,
            'min_threshold': min_threshold,
            'storage_capacity': inv.storage_capacity_units,
            'status': 'Low' if inv.current_level <= min_threshold else 'OK'
        })
    return render_template('inventory.html', inventory_data=inventory_data)

@bp.route('/forecast')
@login_required
def forecast_page():
    if hasattr(current_user, 'role') and current_user.role == 'customer':
        # Get SKUs the customer has ordered (distinct)
        ordered_sku_ids = [row[0] for row in db.session.query(Order.sku_id).filter_by(customer_id=current_user.id).distinct()]
        skus = SKU.query.filter(SKU.sku_id.in_(ordered_sku_ids)).all() if ordered_sku_ids else []
    else:
        skus = SKU.query.all()
    return render_template('forecast.html', skus=skus)

@bp.route('/skus_page', methods=['GET'])
@login_required
def skus_page():
    skus = SKU.query.order_by(SKU.name).all()  # type: ignore
    # Analytics
    total_skus = len(skus)
    category_counts = Counter([sku.category for sku in skus])
    low_stock_skus = [sku.sku_id for sku in skus if hasattr(sku, 'inventory') and any(inv.current_level <= sku.min_threshold for inv in sku.inventory)]
    return render_template('skus_page.html', skus=skus, total_skus=total_skus, category_counts=category_counts, low_stock_skus=low_stock_skus)

@bp.route('/skus', methods=['GET'])
@login_required
def skus_alias():
    return skus_page()

@bp.route('/api/skus')
def get_skus():
    skus = SKU.query.all()
    return jsonify([sku.to_dict() for sku in skus])

@bp.route('/api/sales/<sku_id>')
def get_sales(sku_id):
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = Sales.query.filter_by(sku_id=sku_id)
    
    if start_date:
        query = query.filter(Sales.date >= datetime.strptime(start_date, '%Y-%m-%d').date())
    if end_date:
        query = query.filter(Sales.date <= datetime.strptime(end_date, '%Y-%m-%d').date())
    
    sales = query.order_by(Sales.date).all()
    return jsonify([sale.to_dict() for sale in sales])

@bp.route('/api/inventory/<sku_id>')
def get_inventory(sku_id):
    inventory = Inventory.query.filter_by(sku_id=sku_id).order_by(Inventory.date).all()  # type: ignore
    return jsonify([inv.to_dict() for inv in inventory])

@bp.route('/api/forecast/<sku_id>')
def get_forecast(sku_id):
    days = int(request.args.get('days', 30))
    # Load historical sales data for the SKU
    sales = Sales.query.filter_by(sku_id=sku_id).order_by(Sales.date).all()  # type: ignore
    if not sales:
        return jsonify({'data': [], 'message': 'No sales data available', 'sku_id': sku_id, 'alerts': [], 'recommendation': ''})
    # Prepare DataFrame for Prophet
    sales_df = pd.DataFrame([
        {'date': s.date, 'quantity_sold': s.quantity_sold} for s in sales
    ])
    # Forecast using Prophet
    forecast_df = forecast_sales(sales_df, periods=days)
    # Prepare data for frontend
    forecast_data = [
        {k: (pd.to_datetime(v).strftime('%Y-%m-%d') if k == 'ds' else float(v) if isinstance(v, (int, float, np.floating, np.integer)) or (isinstance(v, str) and v.replace('.', '', 1).isdigit()) else str(v))
         for k, v in row.items()}
        for row in forecast_df.tail(days).to_dict(orient='records')  # type: ignore
    ]
    # Alerts & Recommendations
    alerts = []
    recommendation = ''
    # Get latest inventory
    latest_inventory = Inventory.query.filter_by(sku_id=sku_id).order_by(Inventory.date.desc()).first()  # type: ignore
    if latest_inventory:
        projected_inventory = latest_inventory.current_level
        storage_capacity = latest_inventory.storage_capacity_units
        for f in forecast_data:
            projected_inventory -= f['forecast']
            if projected_inventory < 0 and 'Stock-out risk' not in alerts:
                alerts.append('Stock-out risk: Inventory may drop below zero during forecast period.')
            if projected_inventory > storage_capacity and 'Overstock risk' not in alerts:
                alerts.append('Overstock risk: Inventory may exceed storage capacity.')
        # Production recommendation
        if projected_inventory < 0:
            recommendation = f"Recommended to produce at least {abs(int(projected_inventory))} units to avoid stock-out."
        elif projected_inventory > storage_capacity:
            recommendation = f"Reduce production or increase sales to avoid exceeding storage capacity by {int(projected_inventory - storage_capacity)} units."
        else:
            recommendation = "Inventory levels are within safe limits."
    return jsonify({'data': forecast_data, 'sku_id': sku_id, 'alerts': alerts, 'recommendation': recommendation})

@bp.route('/api/raw_forecast/<sku_id>')
def get_raw_forecast(sku_id):
    days = int(request.args.get('days', 30))
    sales = Sales.query.filter_by(sku_id=sku_id).order_by(Sales.date).all()
    if not sales:
        return jsonify({'data': [], 'message': 'No sales data available', 'sku_id': sku_id})
    sales_df = pd.DataFrame([
        {'date': s.date, 'quantity_sold': s.quantity_sold} for s in sales
    ])
    forecast_df = forecast_sales(sales_df, periods=days)
    # Convert all columns to serializable types
    forecast_data = [
        {k: (pd.to_datetime(v).strftime('%Y-%m-%d') if k == 'ds' else float(v) if isinstance(v, (int, float, np.floating, np.integer)) or (isinstance(v, str) and v.replace('.', '', 1).isdigit()) else str(v))
         for k, v in row.items()}
        for row in forecast_df.tail(days).to_dict(orient='records')  # type: ignore
    ]
    return jsonify({'data': forecast_data, 'sku_id': sku_id})

def is_valid_email(email):
    # Simple regex for email validation
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

@bp.route('/customer_register', methods=['GET', 'POST'])
def customer_register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        # Validation
        if not username or not email or not password:
            flash('All fields are required.', 'danger')
            return render_template('customer_register.html')
        
        if not is_valid_email(email):
            flash('Invalid email address.', 'danger')
            return render_template('customer_register.html')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('customer_register.html')
        
        # Check if username or email already exists in Customer table
        existing_customer = Customer.query.filter(
            (Customer.username == username) | (Customer.email == email)
        ).first()
        
        if existing_customer:
            flash('Username or email already exists.', 'danger')
            return render_template('customer_register.html')
        
        # Check if username or email exists in User table (admin)
        existing_user = User.query.filter(
            (User.username == username) | (User.email == email)
        ).first()
        
        if existing_user:
            flash('Username or email already exists.', 'danger')
            return render_template('customer_register.html')
        
        try:
            # Create new customer
            customer = Customer(
                username=username,
                email=email
            )
            customer.set_password(password)
            
            # Add to database
            db.session.add(customer)
            db.session.commit()
            
            flash('Customer registration successful! Please log in.', 'success')
            return redirect(url_for('main.login'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Registration failed. Please try again. Error: {str(e)}', 'danger')
            return render_template('customer_register.html')
    
    return render_template('customer_register.html')

@bp.route('/admin_register', methods=['GET', 'POST'])
def admin_register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        # Validation
        if not username or not email or not password:
            flash('All fields are required.', 'danger')
            return render_template('admin_registration.html')
        
        if not is_valid_email(email):
            flash('Invalid email address.', 'danger')
            return render_template('admin_registration.html')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('admin_registration.html')
        
        # Check if username or email already exists in User table (admin)
        existing_user = User.query.filter(
            (User.username == username) | (User.email == email)
        ).first()
        
        if existing_user:
            flash('Username or email already exists.', 'danger')
            return render_template('admin_registration.html')
        
        # Check if username or email exists in Customer table
        existing_customer = Customer.query.filter(
            (Customer.username == username) | (Customer.email == email)
        ).first()
        
        if existing_customer:
            flash('Username or email already exists.', 'danger')
            return render_template('admin_registration.html')
        
        try:
            # Create new admin user
            admin_user = User(
                username=username,
                email=email,
                role='admin'
            )
            admin_user.set_password(password)
            
            # Add to database
            db.session.add(admin_user)
            db.session.commit()
            
            flash('Admin registration successful! Please log in.', 'success')
            return redirect(url_for('main.login'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Registration failed. Please try again. Error: {str(e)}', 'danger')
            return render_template('admin_registration.html')
    
    return render_template('admin_registration.html')

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if isinstance(current_user, Customer):
            return redirect(url_for('main.customer_dashboard'))
        elif isinstance(current_user, User):
            return redirect(url_for('main.dashboard'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        login_type = request.form.get('login_type', 'customer')

        if login_type == 'admin':
            user = User.query.filter_by(username=username, role='admin').first()
            if user and user.check_password(password):
                login_user(user)
                session['user_type'] = 'admin'
                flash('Admin login successful!', 'success')
                return redirect(url_for('main.dashboard'))
            else:
                flash('Invalid admin username or password', 'danger')
        elif login_type == 'customer':
            customer = Customer.query.filter_by(username=username).first()
            if customer and customer.check_password(password):
                login_user(customer)
                session['user_type'] = 'customer'
                flash('Customer login successful!', 'success')
                return redirect(url_for('main.customer_dashboard'))
            else:
                flash('Invalid customer username or password', 'danger')
    return render_template('login.html')

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    session.pop('user_type', None)
    flash('You have been logged out.', 'info')
    return redirect(url_for('main.login'))

@bp.route('/customer_dashboard')
@login_required
def customer_dashboard():
    # This page is for customers.
    # Only allow Customer instances to access this page
    if not isinstance(current_user, Customer):
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.dashboard'))
    skus = SKU.query.order_by(SKU.name).all()
    orders = Order.query.filter_by(customer_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template('customer_dashboard.html', user=current_user, skus=skus, orders=orders)

@bp.route('/utilization_dashboard')
@login_required
def utilization_dashboard():
    return render_template('utilization_dashboard.html')

@bp.route('/api/utilization')
@login_required
def get_utilization():
    # Calculate utilization for each SKU and overall
    utilization_data = []
    skus = SKU.query.all()
    start = request.args.get('start')
    end = request.args.get('end')
    for sku in skus:
        query = Inventory.query.filter_by(sku_id=sku.sku_id)
        if start:
            query = query.filter(Inventory.date >= start)
        if end:
            query = query.filter(Inventory.date <= end)
        latest_inventory = query.order_by(Inventory.date.desc()).first()
        if latest_inventory:
            processing_util = min(1.0, sku.processing_time_hours / 24.0) * 100 if sku.processing_time_hours else 0
            packaging_util = min(1.0, sku.packaging_time_hours / 24.0) * 100 if sku.packaging_time_hours else 0
            storage_util = min(1.0, latest_inventory.current_level / latest_inventory.storage_capacity_units) * 100 if latest_inventory.storage_capacity_units else 0
        else:
            processing_util = packaging_util = storage_util = 0
        utilization_data.append({
            'sku_id': sku.sku_id,
            'name': sku.name,
            'processing_utilization': round(processing_util, 2),
            'packaging_utilization': round(packaging_util, 2),
            'storage_utilization': round(storage_util, 2)
        })
    return jsonify(utilization_data)

@bp.route('/add_sample_sales')
@login_required
def add_sample_sales():
    skus = SKU.query.all()
    today = datetime.now().date()
    for sku in skus:
        for i in range(7):  # Add 7 days of sales
            date = today - timedelta(days=i)
            sale = Sales(
                sku_id=sku.sku_id,
                date=date,
                quantity_sold=random.randint(100, 1000),
                revenue=random.uniform(1000, 5000),
                region_id='AHM-01',
                holiday_flag=False,
                festival_flag=False,
                promotional_flag=False,
                temperature_avg=random.uniform(20, 40),
                humidity_avg=random.uniform(30, 90),
                competitor_activity_index=random.uniform(0, 1),
                fuel_price=random.uniform(80, 100)
            )
            db.session.add(sale)
    db.session.commit()
    return 'Sample sales data added! <a href="/dashboard">Go to Dashboard</a>'

@bp.route('/download_forecast/<sku_id>')
def download_forecast(sku_id):
    days = int(request.args.get('days', 30))
    sales = Sales.query.filter_by(sku_id=sku_id).order_by(Sales.date).all()
    if not sales:
        return 'No sales data available', 404
    sales_df = pd.DataFrame([
        {'date': s.date, 'quantity_sold': s.quantity_sold} for s in sales
    ])
    forecast_df = forecast_sales(sales_df, periods=days)
    # Prepare CSV
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(forecast_df.columns)
    for row in forecast_df.tail(days).itertuples(index=False):
        writer.writerow(row)
    output.seek(0)
    return Response(
        output,
        mimetype='text/csv',
        headers={
            'Content-Disposition': f'attachment; filename=forecast_{sku_id}.csv'
        }
    )

@bp.route('/profile')
@login_required
def profile():
    user = User.query.get(session['user_id'])
    return render_template('profile.html', user=user)

@bp.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        user = User.query.filter_by(email=email).first()
        if not user or not user.is_verified:
            flash('If your email is registered and verified, you will receive a reset link.', 'info')
            return redirect(url_for('main.login'))
        # Generate reset token
        token = hashlib.sha256((user.email + str(uuid.uuid4())).encode()).hexdigest()
        user.verification_token = token
        db.session.commit()
        reset_url = url_for('main.reset_password', token=token, _external=True)
        print(f'Password reset link: {reset_url}')
        try:
            msg = Message('Reset your password - Flavi Dairy Solutions', recipients=[user.email])
            msg.body = f'Hi {user.username},\n\nReset your password by clicking the link: {reset_url}\n\nIf you did not request this, ignore this email.'
            mail.send(msg)
        except Exception as e:
            print('Email send failed:', e)
        flash('If your email is registered and verified, you will receive a reset link.', 'info')
        return redirect(url_for('main.login'))
    return render_template('forgot_password.html')

@bp.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    user = User.query.filter_by(verification_token=token).first()
    if not user:
        flash('Invalid or expired reset link.', 'danger')
        return redirect(url_for('main.login'))
    if request.method == 'POST':
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('reset_password.html')
        user.set_password(password)
        user.verification_token = None
        db.session.commit()
        flash('Password reset successful! You can now log in.', 'success')
        return redirect(url_for('main.login'))
    return render_template('reset_password.html')

@bp.route('/admin_profile')
@login_required
def admin_profile():
    if not (hasattr(current_user, 'role') and current_user.role == 'admin'):
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    return render_template('admin_profile.html', user=current_user)

@bp.route('/customer_profile')
@login_required
def customer_profile():
    # Only allow Customer instances
    if not isinstance(current_user, Customer):
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    return render_template('customer_profile.html', user=current_user)

@bp.route('/add_inventory', methods=['GET', 'POST'])
@login_required
def add_inventory():
    if request.method == 'POST':
        try:
            # Support both form and JSON
            if request.is_json:
                data = request.get_json()
                sku_id = data.get('sku_id')
                current_level = data.get('current_level')
                production_batch_size = data.get('production_batch_size')
                shelf_life_days = data.get('shelf_life_days')
                storage_capacity_units = data.get('storage_capacity_units')
                date = data.get('date')
            else:
                sku_id = request.form.get('sku_id')
                current_level = request.form.get('current_level')
                production_batch_size = request.form.get('production_batch_size')
                shelf_life_days = request.form.get('shelf_life_days')
                storage_capacity_units = request.form.get('storage_capacity_units')
                date = request.form.get('date')
            # Validation
            if not all([sku_id, current_level, production_batch_size, shelf_life_days, storage_capacity_units, date]):
                if request.is_json:
                    return jsonify({'success': False, 'message': 'All fields are required.'}), 400
                flash('All fields are required.', 'danger')
                return render_template('add_inventory.html')
            # Check if SKU exists
            sku = SKU.query.filter_by(sku_id=sku_id).first()
            if not sku:
                if request.is_json:
                    return jsonify({'success': False, 'message': 'SKU not found.'}), 404
                flash('SKU not found.', 'danger')
                return render_template('add_inventory.html')
            # Convert numeric fields
            try:
                if None in [current_level, production_batch_size, shelf_life_days, storage_capacity_units, date]:
                    raise ValueError('Missing required numeric value')
                current_level = float(current_level) if current_level is not None else 0.0
                production_batch_size = float(production_batch_size) if production_batch_size is not None else 0.0
                shelf_life_days = int(shelf_life_days) if shelf_life_days is not None else 0
                storage_capacity_units = float(storage_capacity_units) if storage_capacity_units is not None else 0.0
                date = datetime.strptime(date, '%Y-%m-%d').date() if date else datetime.utcnow().date()
            except (ValueError, TypeError):
                if request.is_json:
                    return jsonify({'success': False, 'message': 'Invalid or missing numeric values.'}), 400
                flash('Invalid or missing numeric values.', 'danger')
                return render_template('add_inventory.html')
            # Create new inventory record
            inventory = Inventory(
                sku_id=sku_id,
                current_level=current_level,
                production_batch_size=production_batch_size,
                shelf_life_days=shelf_life_days,
                storage_capacity_units=storage_capacity_units,
                date=date
            )
            # Add to database
            db.session.add(inventory)
            db.session.commit()
            if request.is_json:
                return jsonify({'success': True, 'message': 'Inventory added successfully!'}), 200
            flash('Inventory added successfully!', 'success')
            return redirect(url_for('main.inventory_page'))
        except Exception as e:
            db.session.rollback()
            if request.is_json:
                return jsonify({'success': False, 'message': f'Error adding inventory: {str(e)}'}), 500
            flash(f'Error adding inventory: {str(e)}', 'danger')
            return render_template('add_inventory.html')
    # Get available SKUs for dropdown
    skus = SKU.query.order_by(SKU.name).all()
    return render_template('add_inventory.html', skus=skus)

@bp.route('/edit_inventory/<int:inventory_id>', methods=['POST'])
@login_required
def edit_inventory(inventory_id):
    try:
        # Find existing inventory record
        inventory = Inventory.query.get(inventory_id)
        if not inventory:
            return jsonify({'success': False, 'message': 'Inventory record not found'}), 404
        
        # Get form data
        current_level = request.form.get('current_level')
        production_batch_size = request.form.get('production_batch_size')
        shelf_life_days = request.form.get('shelf_life_days')
        storage_capacity_units = request.form.get('storage_capacity_units')
        date = request.form.get('date')
        
        # Validation
        if not all([current_level, production_batch_size, shelf_life_days, storage_capacity_units, date]):
            return jsonify({'success': False, 'message': 'All fields are required'}), 400
        
        # Convert numeric fields
        try:
            current_level = float(current_level) if current_level is not None else 0.0
            production_batch_size = float(production_batch_size) if production_batch_size is not None else 0.0
            shelf_life_days = int(shelf_life_days) if shelf_life_days is not None else 0
            storage_capacity_units = float(storage_capacity_units) if storage_capacity_units is not None else 0.0
            date = datetime.strptime(date, '%Y-%m-%d').date() if date else datetime.utcnow().date()
        except ValueError:
            return jsonify({'success': False, 'message': 'Invalid numeric values'}), 400
        
        # Update inventory record
        inventory.current_level = current_level
        inventory.production_batch_size = production_batch_size
        inventory.shelf_life_days = shelf_life_days
        inventory.storage_capacity_units = storage_capacity_units
        inventory.date = date
        
        # Save to database
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Inventory updated successfully',
            'inventory': inventory.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error updating inventory: {str(e)}'}), 500

@bp.route('/delete_inventory/<int:inventory_id>', methods=['POST'])
@login_required
def delete_inventory(inventory_id):
    try:
        # Find existing inventory record
        inventory = Inventory.query.get(inventory_id)
        if not inventory:
            return jsonify({'success': False, 'message': 'Inventory record not found'}), 404
        
        # Delete inventory record
        db.session.delete(inventory)
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Inventory deleted successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error deleting inventory: {str(e)}'}), 500

@bp.route('/admin_customers')
@login_required
def admin_customers():
    from app.models.customer import Customer
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    customers = Customer.query.order_by(Customer.id.desc()).all()
    return render_template('admin_customers.html', customers=customers)

@bp.route('/add_sku', methods=['POST'])
@login_required
def add_sku():
    try:
        # Get form data
        sku_id = request.form.get('sku_id')
        name = request.form.get('name')
        category = request.form.get('category')
        packaging_type = request.form.get('packaging_type')
        unit_of_measure = request.form.get('unit_of_measure')
        processing_time_hours = request.form.get('processing_time_hours')
        packaging_time_hours = request.form.get('packaging_time_hours')
        storage_requirement_cubic_meters = request.form.get('storage_requirement_cubic_meters')
        min_threshold = request.form.get('min_threshold', 0)
        description = request.form.get('description')
        
        # Validation
        if not all([sku_id, name, category, packaging_type, unit_of_measure, 
                   processing_time_hours, packaging_time_hours, storage_requirement_cubic_meters]):
            if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'All fields are required'}), 400
            else:
                flash('All fields are required.', 'danger')
                return redirect(url_for('main.skus_page'))
        
        # Check if SKU ID already exists
        existing_sku = SKU.query.filter_by(sku_id=sku_id).first()
        if existing_sku:
            if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'SKU ID already exists'}), 400
            else:
                flash('SKU ID already exists.', 'danger')
                return redirect(url_for('main.skus_page'))
        
        # Convert numeric fields
        try:
            processing_time_hours = float(processing_time_hours) if processing_time_hours is not None else 0.0
            packaging_time_hours = float(packaging_time_hours) if packaging_time_hours is not None else 0.0
            storage_requirement_cubic_meters = float(storage_requirement_cubic_meters) if storage_requirement_cubic_meters is not None else 0.0
            min_threshold = int(float(min_threshold)) if min_threshold else 0
        except ValueError:
            if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'message': 'Invalid numeric values'}), 400
            else:
                flash('Invalid numeric values.', 'danger')
                return redirect(url_for('main.skus_page'))
        
        # Create new SKU
        new_sku = SKU(
            sku_id=sku_id,
            name=name,
            category=category,
            packaging_type=packaging_type,
            unit_of_measure=unit_of_measure,
            processing_time_hours=processing_time_hours,
            packaging_time_hours=packaging_time_hours,
            storage_requirement_cubic_meters=storage_requirement_cubic_meters,
            min_threshold=min_threshold
        )
        if description:
            new_sku.description = description
        
        # Add to database
        db.session.add(new_sku)
        db.session.commit()
        
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({
                'success': True, 
                'message': 'SKU added successfully',
                'sku': new_sku.to_dict()
            }), 201
        else:
            flash('SKU added successfully!', 'success')
            return redirect(url_for('main.skus_page'))
        
    except Exception as e:
        db.session.rollback()
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'message': f'Error adding SKU: {str(e)}'}), 500
        else:
            flash(f'Error adding SKU: {str(e)}', 'danger')
            return redirect(url_for('main.skus_page'))

@bp.route('/edit_sku', methods=['POST'])
@login_required
def edit_sku():
    try:
        # Get form data
        sku_id = request.form.get('sku_id')
        name = request.form.get('name')
        category = request.form.get('category')
        packaging_type = request.form.get('packaging_type')
        unit_of_measure = request.form.get('unit_of_measure')
        processing_time_hours = request.form.get('processing_time_hours')
        packaging_time_hours = request.form.get('packaging_time_hours')
        storage_requirement_cubic_meters = request.form.get('storage_requirement_cubic_meters')
        min_threshold = request.form.get('min_threshold', 0)
        
        # Validation
        if not all([sku_id, name, category, packaging_type, unit_of_measure, 
                   processing_time_hours, packaging_time_hours, storage_requirement_cubic_meters]):
            return jsonify({'success': False, 'message': 'All fields are required'}), 400
        
        # Find existing SKU
        sku = SKU.query.filter_by(sku_id=sku_id).first()
        if not sku:
            return jsonify({'success': False, 'message': 'SKU not found'}), 404
        
        # Convert numeric fields
        try:
            processing_time_hours = float(processing_time_hours) if processing_time_hours is not None else 0.0
            packaging_time_hours = float(packaging_time_hours) if packaging_time_hours is not None else 0.0
            storage_requirement_cubic_meters = float(storage_requirement_cubic_meters) if storage_requirement_cubic_meters is not None else 0.0
            min_threshold = int(float(min_threshold)) if min_threshold else 0
        except ValueError:
            return jsonify({'success': False, 'message': 'Invalid numeric values'}), 400
        
        # Update SKU
        sku.name = name
        sku.category = category
        sku.packaging_type = packaging_type
        sku.unit_of_measure = unit_of_measure
        sku.processing_time_hours = processing_time_hours
        sku.packaging_time_hours = packaging_time_hours
        sku.storage_requirement_cubic_meters = storage_requirement_cubic_meters
        sku.min_threshold = min_threshold
        sku.updated_at = datetime.utcnow()
        
        # Save to database
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'SKU updated successfully',
            'sku': sku.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error updating SKU: {str(e)}'}), 500

@bp.route('/delete_sku', methods=['POST'])
@login_required
def delete_sku():
    try:
        sku_id = request.form.get('sku_id')
        
        if not sku_id:
            return jsonify({'success': False, 'message': 'SKU ID is required'}), 400
        
        # Find existing SKU
        sku = SKU.query.filter_by(sku_id=sku_id).first()
        if not sku:
            return jsonify({'success': False, 'message': 'SKU not found'}), 404
        
        # Check if SKU has related data (sales, inventory)
        has_sales = Sales.query.filter_by(sku_id=sku_id).first() is not None
        has_inventory = Inventory.query.filter_by(sku_id=sku_id).first() is not None
        
        if has_sales or has_inventory:
            return jsonify({
                'success': False, 
                'message': 'Cannot delete SKU. It has related sales or inventory data.'
            }), 400
        
        # Delete SKU
        db.session.delete(sku)
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'SKU deleted successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Error deleting SKU: {str(e)}'}), 500

@bp.route('/place_order', methods=['POST'])
@login_required
def place_order():
    if not isinstance(current_user, Customer):
        flash('You do not have permission to place orders.', 'danger')
        return redirect(url_for('main.customer_dashboard'))
    sku_id = request.form.get('sku_id')
    quantity = request.form.get('quantity')
    if not sku_id or not quantity or int(quantity) < 1:
        flash('Invalid order details.', 'danger')
        return redirect(url_for('main.customer_dashboard'))
    try:
        order = Order(customer_id=current_user.id, sku_id=sku_id, quantity=int(quantity), status='pending')
        db.session.add(order)
        db.session.commit()
        flash(f'Order for SKU {sku_id} (Quantity: {quantity}) placed and sent to admin!', 'success')
        print(f'Order request: Customer {current_user.username} wants {quantity} of {sku_id}')
    except Exception as e:
        db.session.rollback()
        flash(f'Failed to place order: {str(e)}', 'danger')
    return redirect(url_for('main.customer_dashboard'))

@bp.route('/cancel_order', methods=['POST'])
@login_required
def cancel_order():
    if not isinstance(current_user, Customer):
        flash('You do not have permission to cancel orders.', 'danger')
        return redirect(url_for('main.customer_dashboard'))
    sku_id = request.form.get('sku_id')
    # Find the most recent pending order for this SKU and customer
    order = Order.query.filter_by(customer_id=current_user.id, sku_id=sku_id, status='pending').order_by(Order.created_at.desc()).first()
    if order:
        order.status = 'cancelled'
        db.session.commit()
        flash(f'Order for SKU {sku_id} cancelled and admin notified!', 'warning')
        print(f'Cancel request: Customer {current_user.username} cancelled order for {sku_id}')
    else:
        flash('No pending order found to cancel.', 'danger')
    return redirect(url_for('main.customer_dashboard'))

@bp.route('/admin_orders')
@login_required
def admin_orders():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    from app.models.customer import Customer
    from app.models.sku import SKU
    status = request.args.get('status')
    if status:
        orders = Order.query.filter_by(status=status).order_by(Order.created_at.desc()).all()
    else:
        orders = Order.query.order_by(Order.created_at.desc()).all()
    # Attach customer and SKU info for display
    order_data = []
    for order in orders:
        customer = Customer.query.get(order.customer_id)
        sku = SKU.query.filter_by(sku_id=order.sku_id).first()
        order_data.append({
            'id': order.id,
            'customer': customer.username if customer else order.customer_id,
            'sku': sku.name if sku else order.sku_id,
            'quantity': order.quantity,
            'status': order.status,
            'created_at': order.created_at,
        })
    return render_template('admin_orders.html', orders=order_data)

@bp.route('/admin_orders/complete/<int:order_id>', methods=['POST'])
@login_required
def complete_order(order_id):
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to perform this action.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    order = Order.query.get(order_id)
    if order and order.status == 'pending':
        order.status = 'completed'
        from app import db
        db.session.commit()
        flash('Order marked as completed.', 'success')
    else:
        flash('Order not found or not pending.', 'danger')
    return redirect(url_for('main.admin_orders'))

@bp.route('/admin_orders/delete/<int:order_id>', methods=['POST'])
@login_required
def delete_order(order_id):
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to perform this action.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    from app import db
    order = Order.query.get(order_id)
    if order and order.status in ['completed', 'cancelled']:
        db.session.delete(order)
        db.session.commit()
        flash('Order deleted successfully.', 'success')
    else:
        flash('Order not found or not eligible for deletion.', 'danger')
    return redirect(url_for('main.admin_orders'))

@bp.route('/api/pending_orders')
@login_required
def api_pending_orders():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        return {'error': 'Unauthorized'}, 403
    from app.models.order import Order
    from app.models.customer import Customer
    from app.models.sku import SKU
    orders = Order.query.filter_by(status='pending').order_by(Order.created_at.desc()).all()
    data = []
    for order in orders:
        customer = Customer.query.get(order.customer_id)
        sku = SKU.query.filter_by(sku_id=order.sku_id).first()
        data.append({
            'id': order.id,
            'customer': customer.username if customer else order.customer_id,
            'product': sku.name if sku else order.sku_id,
            'date': order.created_at.strftime('%Y-%m-%d %H:%M'),
        })
    return {'orders': data, 'count': len(data)}

@bp.route('/admin_orders/pending')
@login_required
def admin_orders_pending():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    from app.models.customer import Customer
    from app.models.sku import SKU
    from app.models.inventory import Inventory
    orders = Order.query.filter_by(status='pending').order_by(Order.created_at.desc()).all()
    order_data = []
    for order in orders:
        customer = Customer.query.get(order.customer_id)
        sku = SKU.query.filter_by(sku_id=order.sku_id).first()
        # Get latest inventory for this SKU
        latest_inventory = Inventory.query.filter_by(sku_id=order.sku_id).order_by(Inventory.date.desc()).first()
        out_of_stock = False
        if latest_inventory is None or latest_inventory.current_level < order.quantity:
            out_of_stock = True
        order_data.append({
            'id': order.id,
            'customer': customer.username if customer else order.customer_id,
            'sku': sku.name if sku else order.sku_id,
            'quantity': order.quantity,
            'date': order.created_at.strftime('%Y-%m-%d %H:%M'),
            'out_of_stock': out_of_stock
        })
    return render_template('admin_orders_pending.html', orders=order_data)

@bp.route('/dashboard/latest_pending_orders')
@login_required
def latest_pending_orders():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    from app.models.customer import Customer
    from app.models.sku import SKU
    orders = Order.query.filter_by(status='pending').order_by(Order.created_at.desc()).limit(10).all()
    order_data = []
    for order in orders:
        customer = Customer.query.get(order.customer_id)
        sku = SKU.query.filter_by(sku_id=order.sku_id).first()
        order_data.append({
            'id': order.id,
            'customer': customer.username if customer else order.customer_id,
            'sku': sku.name if sku else order.sku_id,
            'quantity': order.quantity,
            'date': order.created_at.strftime('%Y-%m-%d %H:%M'),
        })
    return render_template('latest_pending_orders.html', orders=order_data)

@bp.route('/admin_orders/completed')
@login_required
def admin_orders_completed():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    from app.models.customer import Customer
    from app.models.sku import SKU
    from app.models.inventory import Inventory
    orders = Order.query.filter_by(status='completed').order_by(Order.updated_at.desc()).all()
    order_data = []
    for order in orders:
        customer = Customer.query.get(order.customer_id)
        sku = SKU.query.filter_by(sku_id=order.sku_id).first()
        # Get latest inventory for this SKU at or before the order's updated_at (completion time)
        latest_inventory = Inventory.query.filter(Inventory.sku_id==order.sku_id, Inventory.date<=order.updated_at).order_by(Inventory.date.desc()).first()
        out_of_stock = False
        if latest_inventory is None or latest_inventory.current_level < order.quantity:
            out_of_stock = True
        order_data.append({
            'id': order.id,
            'customer': customer.username if customer else order.customer_id,
            'sku': sku.name if sku else order.sku_id,
            'quantity': order.quantity,
            'date': order.updated_at.strftime('%Y-%m-%d %H:%M'),
            'out_of_stock': out_of_stock
        })
    return render_template('admin_orders_completed.html', orders=order_data)

@bp.route('/api/completed_orders')
@login_required
def api_completed_orders():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        return {'error': 'Unauthorized'}, 403
    from app.models.order import Order
    from app.models.customer import Customer
    from app.models.sku import SKU
    orders = Order.query.filter_by(status='completed').order_by(Order.updated_at.desc()).all()
    data = []
    for order in orders:
        customer = Customer.query.get(order.customer_id)
        sku = SKU.query.filter_by(sku_id=order.sku_id).first()
        data.append({
            'id': order.id,
            'customer': customer.username if customer else order.customer_id,
            'product': sku.name if sku else order.sku_id,
            'quantity': order.quantity,
            'date': order.updated_at.strftime('%Y-%m-%d %H:%M'),
        })
    return {'orders': data, 'count': len(data)}

@bp.route('/admin_orders/latest_completed_orders')
@login_required
def latest_completed_orders():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    from app.models.customer import Customer
    from app.models.sku import SKU
    orders = Order.query.filter_by(status='completed').order_by(Order.updated_at.desc()).limit(10).all()
    order_data = []
    for order in orders:
        customer = Customer.query.get(order.customer_id)
        sku = SKU.query.filter_by(sku_id=order.sku_id).first()
        order_data.append({
            'id': order.id,
            'customer': customer.username if customer else order.customer_id,
            'sku': sku.name if sku else order.sku_id,
            'quantity': order.quantity,
            'date': order.updated_at.strftime('%Y-%m-%d %H:%M'),
        })
    return render_template('latest_completed_orders.html', orders=order_data)

# Users Management Routes
@bp.route('/admin_users')
@login_required
def admin_users():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    
    from app.models.user import User
    from app.models.customer import Customer
    
    # Get all users
    admin_users = User.query.filter_by(role='admin').all()
    customer_users = Customer.query.all()
    
    return render_template('admin_users.html', 
                         admin_users=admin_users, 
                         customer_users=customer_users,
                         total_admins=len(admin_users),
                         total_customers=len(customer_users))

@bp.route('/admin_users/admins')
@login_required
def admin_users_admins():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    
    from app.models.user import User
    admin_users = User.query.filter_by(role='admin').order_by(User.id.desc()).all()
    
    return render_template('admin_users_admins.html', admin_users=admin_users)

@bp.route('/admin_users/customers')
@login_required
def admin_users_customers():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    
    from app.models.customer import Customer
    customer_users = Customer.query.order_by(Customer.created_at.desc()).all()
    
    return render_template('admin_users_customers.html', customer_users=customer_users)

@bp.route('/admin_users/register_admin', methods=['GET', 'POST'])
@login_required
def admin_users_register_admin():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        from app.models.user import User
        
        # Check if user already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return render_template('admin_users_register_admin.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists.', 'danger')
            return render_template('admin_users_register_admin.html')
        
        # Create new admin user
        new_admin = User(username=username, email=email, role='admin')
        new_admin.set_password(password)
        
        from app import db
        db.session.add(new_admin)
        db.session.commit()
        
        flash(f'Admin user "{username}" has been registered successfully!', 'success')
        return redirect(url_for('main.admin_users_admins'))
    
    return render_template('admin_users_register_admin.html')

@bp.route('/admin_users/register_customer', methods=['GET', 'POST'])
@login_required
def admin_users_register_customer():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        from app.models.customer import Customer
        
        # Check if customer already exists
        if Customer.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return render_template('admin_users_register_customer.html')
        
        if Customer.query.filter_by(email=email).first():
            flash('Email already exists.', 'danger')
            return render_template('admin_users_register_customer.html')
        
        # Create new customer
        new_customer = Customer(username=username, email=email)
        new_customer.set_password(password)
        
        from app import db
        db.session.add(new_customer)
        db.session.commit()
        
        flash(f'Customer "{username}" has been registered successfully!', 'success')
        return redirect(url_for('main.admin_users_customers'))
    
    return render_template('admin_users_register_customer.html')

@bp.route('/api/sales_trend/<sku_id>')
@login_required
def api_sales_trend(sku_id):
    from app.models.sales import Sales
    sales = Sales.query.filter_by(sku_id=sku_id).order_by(Sales.date).all()
    data = [{'date': s.date.strftime('%Y-%m-%d'), 'quantity': s.quantity_sold} for s in sales]
    return jsonify({'sales': data}) 

@bp.route('/admin_orders/cancel/<int:order_id>', methods=['POST'])
@login_required
def admin_cancel_order(order_id):
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to perform this action.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    order = Order.query.get(order_id)
    if order and order.status == 'pending':
        order.status = 'cancelled'
        db.session.commit()
        flash('Order cancelled successfully.', 'warning')
    else:
        flash('Order not found or not pending.', 'danger')
    return redirect(url_for('main.dashboard'))

@bp.route('/admin_orders/cancelled')
@login_required
def admin_orders_cancelled():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('You do not have permission to access this page.', 'danger')
        return redirect(url_for('main.index'))
    from app.models.order import Order
    from app.models.customer import Customer
    from app.models.sku import SKU
    from app.models.inventory import Inventory
    orders = Order.query.filter_by(status='cancelled').order_by(Order.updated_at.desc()).all()
    order_data = []
    for order in orders:
        customer = Customer.query.get(order.customer_id)
        sku = SKU.query.filter_by(sku_id=order.sku_id).first()
        # Get latest inventory for this SKU at or before the order's updated_at (cancellation time)
        latest_inventory = Inventory.query.filter(Inventory.sku_id==order.sku_id, Inventory.date<=order.updated_at).order_by(Inventory.date.desc()).first()
        out_of_stock = False
        if latest_inventory is None or latest_inventory.current_level < order.quantity:
            out_of_stock = True
        order_data.append({
            'id': order.id,
            'customer': customer.username if customer else order.customer_id,
            'sku': sku.name if sku else order.sku_id,
            'quantity': order.quantity,
            'date': order.updated_at.strftime('%Y-%m-%d %H:%M'),
            'out_of_stock': out_of_stock
        })
    return render_template('admin_orders_cancelled.html', orders=order_data)

@bp.route('/admin_users/edit/<int:user_id>', methods=['POST'])
@login_required
def edit_admin_user(user_id):
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Permission denied.'}), 403
    from app.models.user import User
    from app import db
    if user_id == current_user.id:
        return jsonify({'success': False, 'message': 'You cannot edit yourself here.'}), 400
    user = User.query.get(user_id)
    if not user or user.role != 'admin':
        return jsonify({'success': False, 'message': 'Admin user not found.'}), 404
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    if username:
        user.username = username
    if email:
        user.email = email
    db.session.commit()
    return jsonify({'success': True, 'message': 'Admin user updated.'})

@bp.route('/admin_users/delete/<int:user_id>', methods=['POST'])
@login_required
def delete_admin_user(user_id):
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        return jsonify({'success': False, 'message': 'Permission denied.'}), 403
    from app.models.user import User
    from app import db
    if user_id == current_user.id:
        return jsonify({'success': False, 'message': 'You cannot delete yourself.'}), 400
    user = User.query.get(user_id)
    if not user or user.role != 'admin':
        return jsonify({'success': False, 'message': 'Admin user not found.'}), 404
    db.session.delete(user)
    db.session.commit()
    return jsonify({'success': True, 'message': 'Admin user deleted.'})

def remove_admin_dashboard_route():
    pass  # This is a placeholder to indicate the route and function should be deleted. 

@bp.route('/api/inventory')
@login_required
def api_inventory():
    inventory_records = Inventory.query.order_by(Inventory.date.desc()).all()
    inventory_data = []
    for inv in inventory_records:
        sku = SKU.query.filter_by(sku_id=inv.sku_id).first()
        min_threshold = sku.min_threshold if sku and sku.min_threshold is not None else 0
        inventory_data.append({
            'id': inv.id,
            'sku_id': inv.sku_id,
            'name': sku.name if sku else inv.sku_id,
            'date': inv.date.strftime('%Y-%m-%d'),
            'current_level': inv.current_level,
            'production_batch_size': inv.production_batch_size,
            'shelf_life_days': inv.shelf_life_days,
            'min_threshold': min_threshold,
            'storage_capacity': inv.storage_capacity_units,
            'status': 'Low' if inv.current_level <= min_threshold else 'OK'
        })
    return jsonify({'inventory': inventory_data})

@bp.route('/api/sales_pie')
def api_sales_pie():
    start = request.args.get('start')
    end = request.args.get('end')
    query = db.session.query(SKU.name, db.func.sum(Sales.revenue)).join(Sales, SKU.sku_id == Sales.sku_id)
    if start:
        query = query.filter(Sales.date >= start)
    if end:
        query = query.filter(Sales.date <= end)
    sales = query.group_by(SKU.name).all()
    labels = [row[0] for row in sales]
    values = [float(row[1] or 0) for row in sales]
    return jsonify({'labels': labels, 'values': values})

@bp.route('/api/forecast/all')
def api_forecast_all():
    days = int(request.args.get('days', 30))
    skus = SKU.query.all()
    all_dates = set()
    sku_forecasts = {}
    for sku in skus:
        sales = Sales.query.filter_by(sku_id=sku.sku_id).order_by(Sales.date).all()
        if not sales:
            continue
        sales_df = pd.DataFrame([
            {'date': s.date, 'quantity_sold': s.quantity_sold} for s in sales
        ])
        forecast_df = forecast_sales(sales_df, periods=days)
        # Use 'yhat' as the forecast value
        forecast_data = [
            {k: (pd.to_datetime(v).strftime('%Y-%m-%d') if k == 'ds' else float(v) if k == 'yhat' else None)
             for k, v in row.items() if k in ['ds', 'yhat']}
            for row in forecast_df.tail(days).to_dict(orient='records')
        ]
        dates = [row['ds'] for row in forecast_data]
        all_dates.update(dates)
        sku_forecasts[sku.name] = {d['ds']: d['yhat'] for d in forecast_data}
    labels = sorted(all_dates)
    datasets = []
    for sku_name, forecast_map in sku_forecasts.items():
        data = [forecast_map.get(date, None) for date in labels]
        datasets.append({ 'label': sku_name, 'data': data })
    return jsonify({ 'labels': labels, 'datasets': datasets })

@bp.route('/api/forecast/all_dashboard')
def api_forecast_all_dashboard():
    range_type = request.args.get('range', 'all')
    days = int(request.args.get('days', 30))
    skus = SKU.query.all()
    all_dates = set()
    sku_forecasts = {}
    today = datetime.today().date()
    if range_type == 'today':
        start_date = today
    elif range_type == '7days':
        start_date = today - timedelta(days=6)
    elif range_type == 'month':
        start_date = today.replace(day=1)
    else:
        start_date = None
    for sku in skus:
        query = Sales.query.filter_by(sku_id=sku.sku_id)
        if start_date:
            query = query.filter(Sales.date >= start_date)
        sales = query.order_by(Sales.date).all()
        if not sales:
            continue
        sales_df = pd.DataFrame([
            {'date': s.date, 'quantity_sold': s.quantity_sold} for s in sales
        ])
        forecast_df = forecast_sales(sales_df, periods=days)
        forecast_data = [
            {k: (pd.to_datetime(v).strftime('%Y-%m-%d') if k == 'ds' else float(v) if k == 'yhat' else None)
             for k, v in row.items() if k in ['ds', 'yhat']}
            for row in forecast_df.tail(days).to_dict(orient='records')
        ]
        dates = [row['ds'] for row in forecast_data]
        all_dates.update(dates)
        sku_forecasts[sku.name] = {d['ds']: d['yhat'] for d in forecast_data}
    labels = sorted(all_dates)
    datasets = []
    for sku_name, forecast_map in sku_forecasts.items():
        data = [forecast_map.get(date, None) for date in labels]
        datasets.append({ 'label': sku_name, 'data': data })
    return jsonify({ 'labels': labels, 'datasets': datasets }) 