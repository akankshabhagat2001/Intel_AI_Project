from flask import Blueprint, jsonify, request
from app.models.sku import SKU
from app.models.sales import Sales
from app.models.inventory import Inventory
from app import db
from datetime import datetime
from flask_login import login_required

bp = Blueprint('api', __name__)

@bp.route('/skus', methods=['GET'])
@login_required
def get_skus():
    skus = SKU.query.all()
    return jsonify([sku.to_dict() for sku in skus])

@bp.route('/sales/<sku_id>', methods=['GET'])
@login_required
def get_sales(sku_id):
    start_date = request.args.get('start_date')
    end_date = request.args.get('end_date')
    
    query = Sales.query.filter_by(sku_id=sku_id)
    
    if start_date:
        query = query.filter(Sales.date >= datetime.strptime(start_date, '%Y-%m-%d').date())
    if end_date:
        query = query.filter(Sales.date <= datetime.strptime(end_date, '%Y-%m-%d').date())
    
    sales = query.order_by(Sales.date).all()
    return jsonify([sale.to_dict() for sale in sales])

@bp.route('/inventory/<sku_id>', methods=['GET'])
@login_required
def get_inventory(sku_id):
    inventory = Inventory.query.filter_by(sku_id=sku_id).order_by(Inventory.date).all()
    return jsonify([inv.to_dict() for inv in inventory])

@bp.route('/forecast/<sku_id>', methods=['GET'])
@login_required
def get_forecast(sku_id):
    # This will be implemented in the ML module
    # For now, return a placeholder response
    return jsonify({
        'data': [],
        'message': 'Forecast functionality will be implemented in the ML module',
        'sku_id': sku_id
    }) 