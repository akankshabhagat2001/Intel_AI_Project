from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from config import Config
from flask_login import LoginManager
from flask_mail import Mail
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
mail = Mail()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    CORS(app)
    login_manager.init_app(app)
    login_manager.login_view = 'main.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'
    mail.init_app(app)

    # Test database connection
    try:
        with app.app_context():
            # Test basic connection
            from sqlalchemy import text
            result = db.session.execute(text('SELECT 1'))
            result.fetchone()
            logger.info("✅ Database connection successful")
    except Exception as e:
        logger.error(f"❌ Database connection failed: {str(e)}")
        # Don't raise here, let the app start but log the error

    # Register custom Jinja filter for rupees
    def rupees(value):
        try:
            return f"₹{float(value):,.2f}"
        except (ValueError, TypeError):
            return value
    app.jinja_env.filters['rupees'] = rupees

    # Register blueprints
    from app.routes.main import bp as main_bp
    from app.routes.api import bp as api_bp
    from app.routes.auth import auth
    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp, url_prefix='/api')
    app.register_blueprint(auth, url_prefix='/auth')

    # Import models here to avoid circular import
    from app.models.customer import Customer
    from app.models.order import Order

    # Register context processor inside app factory
    @app.context_processor
    def inject_user():
        return dict(current_user=get_current_user())

    return app

def get_current_user():
    from flask import session
    from app.models.user import User  # Import here to avoid circular import
    from app.models.customer import Customer
    
    user_id = session.get('user_id')
    if user_id:
        # Try User first, then Customer
        user = User.query.get(user_id)
        if user:
            return user
        
        customer = Customer.query.get(user_id)
        if customer:
            return customer
    
    return None

@login_manager.user_loader
def load_user(user_id):
    from flask import session
    from app.models.user import User
    from app.models.customer import Customer

    user_type = session.get('user_type')
    if user_type == 'admin':
        return User.query.get(int(user_id))
    elif user_type == 'customer':
        return Customer.query.get(int(user_id))
    return None

# Removed the global context_processor registration here 