from prophet import Prophet
import pandas as pd

def forecast_sales(sales_df, periods=30):
    """
    sales_df: DataFrame with columns ['date', 'quantity_sold']
    periods: Number of days to forecast
    Returns: DataFrame with ['ds', 'yhat', 'yhat_lower', 'yhat_upper']
    """
    df = sales_df.rename(columns={'date': 'ds', 'quantity_sold': 'y'})
    m = Prophet()
    m.fit(df)
    future = m.make_future_dataframe(periods=periods)
    forecast = m.predict(future)
    return forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']] 