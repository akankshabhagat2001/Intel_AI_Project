import os
import sys
import random
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Add the project root to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app, db
from app.models.sku import SKU
from app.models.sales import Sales
from app.models.inventory import Inventory
from app.models.user import User

def generate_sample_data():
    app = create_app()
    with app.app_context():
        # Clear existing data
        db.drop_all()
        db.create_all()

        # Create users
        admin = User(username='admin', email='admin@example.com', role='admin')
        admin.set_password('admin123')
        customer1 = User(username='customer1', email='customer1@example.com', role='customer')
        customer1.set_password('cust123')
        customer2 = User(username='customer2', email='customer2@example.com', role='customer')
        customer2.set_password('cust123')
        db.session.add_all([admin, customer1, customer2])
        db.session.commit()
        customers = [customer1, customer2]

        # Create sample SKUs
        skus = [
            {
                'sku_id': 'MILK-1L',
                'name': 'Full Cream Milk 1L Pouch',
                'category': 'Milk',
                'packaging_type': 'Pouch',
                'unit_of_measure': 'Liters',
                'processing_time_hours': 2.0,
                'packaging_time_hours': 0.5,
                'storage_requirement_cubic_meters': 0.001
            },
            {
                'sku_id': 'CURD-500G',
                'name': 'Curd 500g Cup',
                'category': 'Curd',
                'packaging_type': 'Cup',
                'unit_of_measure': 'Grams',
                'processing_time_hours': 4.0,
                'packaging_time_hours': 0.3,
                'storage_requirement_cubic_meters': 0.0005
            },
            {
                'sku_id': 'BUTTER-100G',
                'name': 'Butter 100g Pack',
                'category': 'Butter',
                'packaging_type': 'Pack',
                'unit_of_measure': 'Grams',
                'processing_time_hours': 6.0,
                'packaging_time_hours': 0.2,
                'storage_requirement_cubic_meters': 0.0002
            }
        ]

        for sku_data in skus:
            sku = SKU(**sku_data)
            db.session.add(sku)
        db.session.commit()

        # Generate dates for the last year
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=365)
        dates = pd.date_range(start_date, end_date, freq='D')

        # Generate sample sales data
        for sku in SKU.query.all():
            # Base demand with seasonality
            base_demand = {
                'MILK-1L': 1000,
                'CURD-500G': 500,
                'BUTTER-100G': 200
            }[sku.sku_id]

            for i, date in enumerate(dates):
                # Add seasonality (higher in summer)
                month = date.month
                seasonality = 1 + 0.2 * np.sin(2 * np.pi * (month - 1) / 12)

                # Add weekly pattern (higher on weekends)
                weekday = date.weekday()
                weekly_pattern = 1.2 if weekday >= 5 else 1.0

                # Add random noise
                noise = np.random.normal(1, 0.1)

                # Calculate quantity sold
                quantity = int(base_demand * seasonality * weekly_pattern * noise)

                # Alternate sales between customer1 and customer2
                user = customers[i % 2]

                # Generate sales record
                sale = Sales(
                    sku_id=sku.sku_id,
                    date=date.date(),
                    quantity_sold=quantity,
                    revenue=quantity * random.uniform(40, 60),
                    region_id='AHM-01',
                    holiday_flag=random.random() < 0.05,
                    festival_flag=random.random() < 0.02,
                    promotional_flag=random.random() < 0.1,
                    temperature_avg=random.uniform(20, 40),
                    humidity_avg=random.uniform(30, 90),
                    competitor_activity_index=random.uniform(0, 1),
                    fuel_price=random.uniform(80, 100),
                    user_id=user.id
                )
                db.session.add(sale)

        # Generate sample inventory data
        for sku in SKU.query.all():
            current_level = random.uniform(500, 2000)
            for date in dates:
                inventory = Inventory(
                    sku_id=sku.sku_id,
                    date=date.date(),
                    current_level=current_level,
                    production_batch_size=random.uniform(1000, 2000),
                    shelf_life_days=random.randint(5, 15),
                    storage_capacity_units=random.uniform(5000, 10000)
                )
                db.session.add(inventory)
                # Update current level for next day
                current_level = max(0, current_level + random.uniform(-200, 200))

        db.session.commit()
        print("Sample data generated successfully!")

if __name__ == '__main__':
    generate_sample_data() 