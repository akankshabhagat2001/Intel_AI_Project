import sqlite3

# Adjust the path if your database file is not in the root directory
conn = sqlite3.connect('instance/flavi_dairy_forecasting_ai.sqlite')  # Change filename if needed
c = conn.cursor()

try:
    # Disable foreign key constraints
    c.execute('PRAGMA foreign_keys=OFF;')

    # Show current schema for reference
    print('Current user table schema:')
    c.execute("PRAGMA table_info(user)")
    for row in c.fetchall():
        print(row)

    # 1. Create a new table without the columns
    c.execute('''
    CREATE TABLE user_new AS SELECT id, username, email, password_hash, role FROM user;
    ''')

    # 2. Drop the old table
    c.execute('DROP TABLE user;')

    # 3. Rename the new table
    c.execute('ALTER TABLE user_new RENAME TO user;')

    # Re-enable foreign key constraints
    c.execute('PRAGMA foreign_keys=ON;')

    conn.commit()
    print('Columns is_verified and verification_token removed successfully.')
except Exception as e:
    print('Error:', e)
finally:
    conn.close() 